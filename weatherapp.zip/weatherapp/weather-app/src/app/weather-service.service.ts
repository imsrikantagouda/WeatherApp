import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';
import { WeatherData } from './contract/WeatherData';


@Injectable({
  providedIn: 'root'
})
export class WeatherService {

  constructor(private http:HttpClient) { }

  header = new HttpHeaders()
  .set('content-type','application/json')
  .set('Access-Control-Allow-Origin',"*");

  public baseUrl:string = "http://skyweather.eu-north-1.elasticbeanstalk.com/weather";

  public GetWeatherData(city_name:string):Observable<WeatherData>{
    return this.http.get<WeatherData>(this.baseUrl+'/'+city_name,{headers:this.header});
  }



}