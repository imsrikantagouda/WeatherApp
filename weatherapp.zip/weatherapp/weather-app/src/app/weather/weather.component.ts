import { Component, Injectable } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { WeatherData } from '../contract/WeatherData';
import { WeatherService } from '../weather-service.service';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-weather',
  templateUrl: './weather.component.html',
  styleUrls: ['./weather.component.css'],
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatIconModule,
    MatProgressBarModule,
    MatInputModule,
    MatInputModule,
    MatCardModule,
    MatButtonModule,
  ],
})
export class WeatherComponent {
  errorMessage: string = '';

  cityName: string = 'mumbai';
  public weatherData: WeatherData = {
    main: {
      temp: 0,
      temp_mins: 0,
      temp_min: 0,
      temp_max: 0,
      pressure: 0,
      humidity: 0,
    },
    name: '',
    weather: ([] = [
      {
        id: 0,
        main: '',
        description: '',
        icon: '',
      },
    ]),
  };

  constructor(private serv: WeatherService) {}
  ngOnInit() {
    this.getWeatherdata(this.cityName);
    this.cityName = '';
  }
  private getWeatherdata(_cityName: string) {
    this.serv.GetWeatherData(this.cityName).subscribe(
      (data) => {
        this.weatherData = data;

        console.log(this.weatherData);
      },
      (error) => {
        this.errorMessage = 'City not found. plese Enter Valid city ';
      },
      () => {
        console.log('API Call done');
      }
    );
  }
  setCity(arg0: string) {
    this.cityName = arg0;
    this.getWeatherdata(this.cityName);
    this.cityName = '';
    this.errorMessage = '';
  }

  temp: number = 0;

  roundTemperature(temp: number): number {
    return Math.round(temp);
  }
}
