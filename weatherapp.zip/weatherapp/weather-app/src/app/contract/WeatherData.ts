
    export interface WeatherData {
            main: Main
            name: string
            weather: Weather[]
          }
          
          export interface Main {
            temp: number
            temp_mins: number
            temp_min: number
            temp_max: number
            pressure: number
            humidity: number
          }
          
          export interface Weather {
            id: number
            main: string
            description: string
            icon: string
          }  
        
      

