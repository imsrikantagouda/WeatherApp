package com.skyweather.skyclear.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class WeatherData {

	@JsonProperty("main")
	private Main main;

	@JsonProperty("name")
	private String cityName;

	@JsonProperty("weather")
	private Weather[] weatherDetails;
}
