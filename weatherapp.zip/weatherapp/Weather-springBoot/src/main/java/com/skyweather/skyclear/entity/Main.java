package com.skyweather.skyclear.entity;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Setter
@Getter
@Component
@AllArgsConstructor
@NoArgsConstructor
public class Main {
	 @JsonProperty("temp")
    private double temp;
	 @JsonProperty("temp_mins")
    private double feels_like;
	 @JsonProperty("temp_min")
    private double temp_min;
	 @JsonProperty("temp_max")
    private double temp_max;
	 @JsonProperty("pressure")
    private int pressure;
	 @JsonProperty("humidity")
    private int humidity;

}

