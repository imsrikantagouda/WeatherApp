package com.skyweather.skyclear.controllor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.skyweather.skyclear.entity.WeatherData;
import com.skyweather.skyclear.service.WeatherService;
import com.skyweather.skyclear.service.WeatherServiceException;

@RestController
public class WeatherController {

	@Autowired
	private WeatherService weatherService;
	
	  @CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.OPTIONS})
	@RequestMapping(value = "/weather/{city}", method = RequestMethod.GET)
	public ResponseEntity<?> getWeather(@PathVariable String city) {
		try {
			WeatherData weatherData = weatherService.getWeatherData(city);
			return ResponseEntity.ok(weatherData);
		} catch (WeatherServiceException e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
		
		
	
	}

}