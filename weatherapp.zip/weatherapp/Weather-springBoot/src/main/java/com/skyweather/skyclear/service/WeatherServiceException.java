package com.skyweather.skyclear.service;



@SuppressWarnings("serial")
public class WeatherServiceException extends RuntimeException {

	
	public WeatherServiceException(String message) {
		super(message);
		
	}

	
}
