package com.skyweather.skyclear.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.skyweather.skyclear.entity.WeatherData;


@Service
public class WeatherService {

	private static final String API_KEY = "YOUR_API_KEY";
	private static final String API_URL = "https://api.openweathermap.org/data/2.5/weather";

	private final RestTemplate restTemplate;

	@Autowired
	public WeatherService(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	public WeatherData getWeatherData(String city) throws WeatherServiceException {

		try {
			ResponseEntity<WeatherData> response = restTemplate
					.getForEntity(API_URL + "?q=" + city + "&units=metric&appid=" + API_KEY, WeatherData.class);
			if (response.getStatusCode() == HttpStatus.OK) {
				return response.getBody();
			} else {
				throw new WeatherServiceException(
						"Failed to fetch weather data. Status code: " + response.getStatusCode());
			}
		} catch (HttpClientErrorException e) {
			throw new WeatherServiceException("Failed to fetch weather data. Reason: " + e.getMessage());
		}
	}

}
